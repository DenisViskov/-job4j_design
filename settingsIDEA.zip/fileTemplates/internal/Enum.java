#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * Enum 
 *
 * @author Денис Висков
 * @version 1.0
 * @since ${DATE}
 */
public enum ${NAME} {
}
