import static org.junit.Assert.*;
import static org.hamcrest.core.Is.is;
#parse("File Header.java")
public class ${NAME} {
  ${BODY}
}