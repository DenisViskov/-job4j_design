@org.junit.Test
public void ${NAME}Test() {
  ${BODY}
}